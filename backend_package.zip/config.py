# config.py
# 数据库配置
db_config = {
    'host': '125.91.113.114',
    'user': 'root',
    'password': 'Report@123',
    'database': 'sales',
    'charset': 'utf8mb4'
}