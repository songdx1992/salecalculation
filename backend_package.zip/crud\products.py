from typing import List, Dict
from decimal import Decimal
from backend.db import get_db_connection
from fastapi import HTTPException
from backend.models import ProductAdd,Product
from typing import Optional, List, Dict




def fetch_db_products(name: Optional[str] = None) -> List[Dict]:
    """
    从数据库读取所有自定义产品
    返回列表，字段应包括 id, name, cost_unit_price, shipping_fee, cost_tax_rate
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = "SELECT id, name, cost_unit_price, shipping_fee, cost_tax_rate FROM ods_marketingcalculation_product"

            params = []
            if name:
                sql += " WHERE name LIKE %s"
                params.append(f"%{name}%")
            print("SQL:", sql)
            print("Params:", params)

            cursor.execute(sql, params)
            rows = cursor.fetchall()
            # 转换Decimal为浮点数，保留两位小数
            for row in rows:
                for key in ['cost_unit_price', 'shipping_fee', 'cost_tax_rate']:
                    if key in row and isinstance(row[key], Decimal):
                        row[key] = round(float(row[key]), 2)

        return rows

    finally:
        conn.close()


def products_data(name: Optional[str] = None) -> List[Dict]:
    """
    合并静态产品和数据库新增产品，返回总列表
    """
    db_list = fetch_db_products(name)
    # 合并：静态数据 + 数据库数据，若 id 冲突，可选择覆盖或跳过，此处直接拼接
    return db_list



def add_product_to_db(product: ProductAdd) -> dict:
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # 检查产品名称是否存在
            cursor.execute("SELECT COUNT(1) AS count FROM ods_marketingcalculation_product WHERE name = %s", (product.name,))
            result = cursor.fetchone()
            if result["count"] > 0:
                raise HTTPException(status_code=400, detail="产品名称已存在")

            # 插入新产品
            cursor.execute("""
                     INSERT INTO ods_marketingcalculation_product (name, cost_unit_price, shipping_fee, cost_tax_rate)
                     VALUES (%s, %s, %s, %s)
                 """, (product.name, product.cost_unit_price, product.shipping_fee, product.cost_tax_rate))
            conn.commit()
            return {"success": True, "message": "产品添加成功"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"数据库错误: {str(e)}")
    finally:
        conn.close()


def deleteproduct(product_id: int):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # 查询产品是否存在
            cursor.execute("SELECT id FROM ods_marketingcalculation_product WHERE id = %s", (product_id,))
            result = cursor.fetchone()
            if not result:
                return {"success": False, "message": "产品不存在"}

            # 删除产品
            cursor.execute("DELETE FROM ods_marketingcalculation_product WHERE id = %s", (product_id,))
            conn.commit()
        return {"success": True}
    except Exception as e:
        print("删除产品时发生错误：", e)
        return {"success": False, "message": "删除失败"}
    finally:
        conn.close()

def dbimport_products(products: List[ProductAdd]):
    print("准备导入数据：", products)
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            # 获取已有产品名称
            cursor.execute("SELECT name FROM ods_marketingcalculation_product")
            existing_names = {row['name'] for row in cursor.fetchall()}
            new_names = set()

            # 校验重复和格式
            for p in products:
                if p.name in existing_names or p.name in new_names:
                    raise HTTPException(status_code=400, detail=f"Duplicate name: {p.name}")
                new_names.add(p.name)

            # 批量插入
            insert_sql = """
                INSERT INTO ods_marketingcalculation_product (name, cost_unit_price, shipping_fee, cost_tax_rate)
                VALUES (%s, %s, %s, %s)
            """
            insert_data = [
                (p.name, float(p.cost_unit_price), float(p.shipping_fee), float(p.cost_tax_rate))
                for p in products
            ]
            cursor.executemany(insert_sql, insert_data)
            conn.commit()
        return {"imported": len(products)}
    except Exception as e:
        print(f"[导入失败] 错误信息：{e}")  # ✅ 控制台日志
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        conn.close()





if __name__ == '__main__':
    products_data()



